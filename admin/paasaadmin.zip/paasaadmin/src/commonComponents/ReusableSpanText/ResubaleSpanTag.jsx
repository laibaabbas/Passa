import React from 'react'

const ResubaleSpanTag = ({text}) => {
  return (
   <span>{text}</span>
  )
}

export default ResubaleSpanTag